#include <DHTesp.h>

#define LED_PIN      2
#define BUTTON_PIN   4
#define BUZZER_PIN   15
#define DHT_PIN      18

DHTesp dht;

void setup() {

  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);

  digitalWrite(BUZZER_PIN, LOW);

  dht.setup(DHT_PIN, DHTesp::DHT22);

  Serial.println("ESP32 Sensor Demo");
}

void loop() {

  TempAndHumidity data = dht.getTempAndHumidity();

  Serial.print("Temperature: ");
  Serial.print(data.temperature);
  Serial.println(" °C");

  Serial.print("Humidity: ");
  Serial.print(data.humidity);
  Serial.println(" %");

  if (digitalRead(BUTTON_PIN) == LOW) {

    digitalWrite(LED_PIN, HIGH);

    tone(BUZZER_PIN, 1000);

    delay(300);

    noTone(BUZZER_PIN);

  } else {

    digitalWrite(LED_PIN, LOW);

  }

  if (data.temperature > 30) {

    tone(BUZZER_PIN, 2000);

    delay(500);

    noTone(BUZZER_PIN);

  }

  delay(1500);
}
